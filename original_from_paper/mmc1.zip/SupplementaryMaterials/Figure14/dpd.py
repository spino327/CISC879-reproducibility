from hoomd_script import *
import math

rho = float(option.get_user()[0])
phi_p = (math.pi/6.0)*rho

globals.msg.notice(1,str(option.get_user())+"\n")

init.create_random(phi_p=phi_p,N=2000000,min_dist=0.001)

# DPD thermostat
dpd = pair.dpd(r_cut=float(option.get_user()[1]), T=1.0)
dpd.pair_coeff.set('A', 'A', A=75.0/rho, gamma = 4.5)
integrate.mode_standard(dt=0.005)

all=group.all()
integrate.nve(group=all)

(r_buff, period) = tune.r_buff(warmup=1e4)
nlist.set_params(dist_check=False,check_period=period+1)
run(5e2,profile=True)

# warmup run
run(30000)

# measurement run
run(5e4)
