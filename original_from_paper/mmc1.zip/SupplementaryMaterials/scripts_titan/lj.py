from hoomd_script import *
import sys

configfile = sys.argv[1]
init.read_xml(configfile)

# specify Lennard-Jones interactions between particle pairs
lj = pair.lj(r_cut=3.0)
lj.pair_coeff.set('1', '1', epsilon=1.0, sigma=1.0)

# integrate at constant temperature
all = group.all();
integrate.mode_standard(dt=0.002)
integrate.nvt(group=all, T=1.0, tau=0.5)

nlist.set_params(r_buff=0.4,check_period=5,dist_check=True)

#logfile = sys.argv[2]
#analyze.log(filename=logfile, quantities=['pair_lj_energy','kinetic_energy'],
#          period=1000, header_prefix='#', overwrite=True)
          
#globals.system.getCommunicator().setMaxStages(3)
# Warming up
run(20000)

tune.r_buff(warmup=10000,set_max_check_period=True,r_min=0.4,jumps=11,r_max=1.5)

# Benchmark run
#run(10000, profile=True)
run(30000)
