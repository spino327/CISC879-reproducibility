#!/bin/sh

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
echo "<hoomd_xml version=\"1.3\">"
echo "<configuration dimensions=\"3\">"

# dump file format: id type x y z
# Positions
awk -v EPSILON=0.00001 'BEGIN{ lx = 0.0; ly = 0.0; lz = 0.0; xlo = xhi = ylo = yhi = zlo = zhi = 0.0; } { 
  if (NF == 5 && NR > 9) {
    if ($3 < xlo) { 
      x = $3 + lx;
    } else if ($3 > xhi) { 
      x = $3 - lx;
    } else x = $3;
    
    if ($4 < ylo-EPSILON) {
      y = $4 + ly;
    } else if ($4 > yhi+EPSILON) { 
      y = $4 - ly;
    } else {
      y = $4;
    }

    if ($5 < zlo-EPSILON) {
      z = $5 + lz;
    } else if ($5 > zhi+EPSILON) {
      z = $5 - lz;
    } else {
      z = $5;
    }

    x = -lx/2.0 + (x - xlo)/(xhi - xlo) * lx;
    y = -ly/2.0 + (y - ylo)/(yhi - ylo) * ly;
    z = -lz/2.0 + (z - zlo)/(zhi - zlo) * lz;
    if (x < -lx/2.0 || x > lx/2.0) {
      printf("tag %d: x %f y %f z %f; read in %f %f %f; xlo xhi: %f %f\n", 
        $1, x, y, z, $3, $4, $5, xlo, xhi);	
    }
    if (y < -ly/2.0 || y > ly/2.0) {
      printf("tag %d: %f %f %f; read in %f %f %f; ylo yhi: %f %f\n", 
        $1, x, y, z, $3, $4, $5, ylo, yhi);	
    }
    if (z < -lz/2.0 || z > lz/2.0) {
      printf("tag %d: %f %f %f; read in %f %f %f; zlo zhi: %f %f\n", 
        $1, x, y, z, $3, $4, $5, zlo, zhi);	
    }

    printf("%lf\t%lf\t%lf\n", x, y, z);	
  } else if (NR == 6) {
    printf("<box lx=\"%lf\" ", $2-$1);
    lx = $2 - $1;
    xlo = $1; xhi = $2;
  } else if (NR == 7) {
    printf("ly=\"%lf\" ", $2-$1);
    ly = $2 - $1;
    ylo = $1; yhi = $2;
  } else if (NR == 8) {
    printf("lz=\"%lf\"\/>\n", $2-$1);
    lz = $2 - $1;
    zlo = $1; zhi = $2;
    printf("<position num=\"%d\">\n", natoms);
  } else if (NR == 4) {
    natoms = $1	
  }

} END{
  printf("<\/position><type>\n");
}' $1 

# Types
awk '{ if (NF == 5 && NR > 9) {
  printf("%d\n", $2); 
  }
} END{
  printf("<\/type>\n<\/configuration>\n<\/hoomd_xml>\n");
}' $1 

